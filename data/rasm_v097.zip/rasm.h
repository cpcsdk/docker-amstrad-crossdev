

extern "C" {

int RasmAssemble(const char *datain, int lenin, unsigned char **dataout, int *lenout);

};


